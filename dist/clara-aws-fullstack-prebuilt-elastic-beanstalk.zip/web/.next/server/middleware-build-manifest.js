globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/S-s-b6s2vsDhhgDH9JHh8/_buildManifest.js",
    "static/S-s-b6s2vsDhhgDH9JHh8/_ssgManifest.js",
    "static/S-s-b6s2vsDhhgDH9JHh8/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1jq4o6yq14o4c.js",
    "static/chunks/0atut6a2uuyid.js",
    "static/chunks/2nykiepra7i1k.js",
    "static/chunks/turbopack-3i0d1wb0b07u8.js"
  ]
};
