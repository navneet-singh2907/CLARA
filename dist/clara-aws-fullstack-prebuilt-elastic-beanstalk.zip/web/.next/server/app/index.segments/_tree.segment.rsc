:HL["/_next/static/chunks/1mzldl5pu_8e4.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}},"staleTime":300,"buildId":"S-s-b6s2vsDhhgDH9JHh8"}
