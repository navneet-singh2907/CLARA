self.__BUILD_MANIFEST = {
  "__rewrites": {
    "afterFiles": [
      {
        "source": "/health"
      },
      {
        "source": "/readiness"
      },
      {
        "source": "/cases"
      },
      {
        "source": "/evaluation"
      },
      {
        "source": "/ablation"
      },
      {
        "source": "/guardrails"
      },
      {
        "source": "/drift"
      },
      {
        "source": "/judge-agreement"
      },
      {
        "source": "/report"
      },
      {
        "source": "/docs"
      },
      {
        "source": "/openapi.json"
      },
      {
        "source": "/favicon.ico"
      },
      {
        "source": "/review/:path*"
      },
      {
        "source": "/evaluation/:path*"
      },
      {
        "source": "/drift/:path*"
      },
      {
        "source": "/judge-agreement/:path*"
      },
      {
        "source": "/report/:path*"
      }
    ],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/_app",
    "/_error"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()