"""Human-review intelligence helpers."""

